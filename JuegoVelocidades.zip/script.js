let bicicleta = document.getElementById("bicicleta");
let lineaBlanca = document.getElementById("lineaBlanca");
let lineaRoja = document.getElementById("lineaRoja");
let resultado = document.getElementById("resultado");
let animacion = null;
let velocidad = 0;
let posicion = 0;

let resultados = { 
    velocidad1: [],
    velocidad2: [],
    vfd: []
};

let currentMode = null;
let isMoving = false; // Estado para saber si la bicicleta está en movimiento

function startSimulation(modo) {
    // Si la bicicleta ya se está moviendo, detenerla
    if (isMoving) {
        clearInterval(animacion); // Detener la animación
        isMoving = false; // Cambiar el estado a detenido
        checkDistance(modo); // Calcular el desfase al detenerse
    } else {
        // Si la bicicleta está detenida, comenzar el movimiento
        currentMode = modo;
        isMoving = true;
        posicion = 0; // Reiniciar la posición
        bicicleta.style.left = "0px";
        resultado.innerText = ""; // Limpiar el resultado

        // Configurar la velocidad según el modo
        if (modo === "velocidad1") {
            velocidad = 30;
        } else if (modo === "velocidad2") {
            velocidad = 30;
            setTimeout(() => velocidad = 20, 1000); // Cambio de velocidad después de un segundo
        } else if (modo === "vfd") {
            // Velocidades iniciales para VFD
            let velocidadInicial = 2;   // Velocidad inicial
            let velocidadFinal = 2;     // Velocidad final
            let velocidadMedia = 20.5;    // Velocidad media
            let velocidadActual = velocidadInicial; // Velocidad actual de la bicicleta
            let acelerando = true;      // Bandera para saber si estamos acelerando o desacelerando
            let incremento = 0.55;       // Incremento/decremento en la velocidad
            let intervaloTiempo = 50;   // Intervalo de tiempo para cada actualización del movimiento
        
            // Inicializamos la velocidad
            velocidad = velocidadInicial;
        
            // Aceleración: aumentamos hasta la velocidad media
            let intervaloAceleracion = setInterval(() => {
                if (velocidad < velocidadMedia) {
                    velocidad += incremento; // Aceleramos gradualmente
                } else {
                    clearInterval(intervaloAceleracion); // Detenemos la aceleración
                    // Comenzamos la desaceleración
                    let intervaloDesaceleracion = setInterval(() => {
                        if (velocidad > velocidadFinal) {
                            velocidad -= incremento; // Desaceleramos gradualmente
                        } else {
                            clearInterval(intervaloDesaceleracion); // Detenemos la desaceleración
                        }
                    }, intervaloTiempo);
                }
            }, intervaloTiempo);
        
            // Iniciamos el movimiento de la bicicleta
            animacion = setInterval(moveBike, intervaloTiempo);
        }
        
        // Iniciar la animación (para otros modos si es necesario)
        if (modo !== "vfd") {
            animacion = setInterval(moveBike, 50);
        }
    }
}

function moveBike() {
    posicion += velocidad;
    bicicleta.style.left = posicion + "px";

    // Comprobar si la bicicleta ha cruzado la línea blanca
    if (bicicleta.getBoundingClientRect().right >= lineaBlanca.getBoundingClientRect().left) {
        // Detener la animación cuando la bicicleta llega a la línea blanca
        clearInterval(animacion);
        isMoving = false; // Cambiar el estado a detenido
        checkDistance(currentMode); // Calcular el desfase al llegar a la línea blanca
    }
}

function checkDistance(modo) {
    let lineaPos = lineaRoja.getBoundingClientRect().left;
    let biciPos = bicicleta.getBoundingClientRect().right;

    let diferenciaPx = Math.abs(lineaPos - biciPos);
    let diferenciaCm = diferenciaPx / 10;

    resultados[modo].push(diferenciaCm.toFixed(2));

    let mensaje = `Desfase: ${diferenciaCm.toFixed(2)} cm<br>`;

    resultado.innerHTML = mensaje;

    showFinalResults();
}

function showFinalResults() {
    let mensaje = "";

    let buttonData = {
        velocidad1: { color: "white", nombre: "1 Velocidad" },
        velocidad2: { color: "white", nombre: "2 Velocidades" },
        vfd: { color: "white", nombre: "Variador de Frecuencia" }
    };

    // Crear una fila vacía para cada modo
    for (let modo in buttonData) {
        let color = buttonData[modo].color;
        let nombre = buttonData[modo].nombre;

        
    }

    mensaje += `</table>`;

    resultado.innerHTML = mensaje;

    // Actualizar las filas con los resultados
    for (let modo in resultados) {
        let desfase = resultados[modo].length > 0 ? parseFloat(resultados[modo][resultados[modo].length - 1]) : 0;
        let color = desfase <= 0.5 ? "#90EE90" : "#FF7F7F";
        
        // Solo actualizar si hay un resultado
        if (desfase > 0) {
            let row = document.getElementById(`row-${modo}`);
            let td = row.querySelector("td:nth-child(2)");
            td.innerHTML = `${desfase.toFixed(2)} cm`;
            td.style.backgroundColor = color;
        }
    }
    function checkDistance(modo) {
        let lineaPos = lineaRoja.getBoundingClientRect().left;
        let biciPos = bicicleta.getBoundingClientRect().right;
    
        let diferenciaPx = Math.abs(lineaPos - biciPos);
        let diferenciaCm = diferenciaPx / 10;
    
        resultados[modo].push(diferenciaCm.toFixed(2));
    
        let mensaje = `Desfase: ${diferenciaCm.toFixed(2)} cm<br>`;
    
        resultado.innerHTML = mensaje;
    
        showFinalResults();
    
        // Llamar a completar SCORM después de la simulación
        completarSCORM(); // Marcar como completado
    }
    
    function completarSCORM() {
        if (scorm.isInitialized()) {
            var lessonStatus = scorm.get("cmi.core.lesson_status");
            
            // Si la lección no está ya completada, marcarla como completada
            if (lessonStatus !== "completed") {
                scorm.set("cmi.core.lesson_status", "completed");
                scorm.save();
                console.log("Curso marcado como completado.");
            } else {
                console.log("El curso ya está marcado como completado.");
            }
    
            scorm.quit();
        } else {
            console.error("SCORM no está inicializado correctamente.");
        }
    }
    
}


