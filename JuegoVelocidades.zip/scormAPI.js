var scorm = pipwerks.SCORM;
scorm.version = "1.2";

function iniciarSCORM() {
    if (scorm.init()) {
        console.log("SCORM iniciado correctamente.");
        scorm.set("cmi.core.lesson_status", "incomplete");
    } else {
        console.error("Error al iniciar SCORM.");
    }
}

function completarSCORM() {
    if (scorm.isInitialized()) {
        scorm.set("cmi.core.lesson_status", "completed");
        scorm.save();
        console.log("Actividad completada.");
        scorm.quit();
    } else {
        console.error("SCORM no está inicializado.");
    }
}

window.onload = function () {
    iniciarSCORM();
}

window.onbeforeunload = function () {
    if (scorm.isInitialized()) {
        scorm.quit();
    }
}
